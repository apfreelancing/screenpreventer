Scripts in this directory may be copied and used freely, but
may be removed or modified without notice by any future release.
Do not #include them directly; instead, create a copy.